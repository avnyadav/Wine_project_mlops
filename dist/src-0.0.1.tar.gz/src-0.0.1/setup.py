from setuptools import setup,find_packages

setup(
    name="src",
    version='0.0.1',
    description="It's wine Q package",
    author="avnish",
    packages=find_packages(),
    license="MIT",

)
